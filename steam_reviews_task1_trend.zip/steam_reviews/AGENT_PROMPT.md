# 工作1：趋势词检测：复制以下提示词给 Agent

```text
你收到的是已经实现Steam英文评论采集和清洗的Python项目，我负责的是下游工作1：趋势词检测。请先读README.md、docs/API_GUIDE.md、docs/DATA_DICTIONARY.md，按以下要求自主完成本角色的数据接入和算法开发。

先安装启动并验证数据，不要只写方案。优先Python3.12，使用项目自己的虚拟环境。macOS使用setup.command/start.command，Windows PowerShell使用.\setup.bat/.\start.bat。所有新增代码、结果、日志保存在该项目目录内。现有cs2_reviews/采集清洗模块、requirements和启动脚本保持不变，在独立下游模块扩展。只实现本角色的数据分析与结果接口，服务和分析在组员本机运行，不依赖原开发者电脑。

一、必须按游戏独立处理
1. CS2=730，Dota 2=570，影之刃零Phantom Blade Zero=4115450。通过GET /v1/games核对目录，所有health/reviews/changes/单条API请求显式传app_id，所有示例消费者显式传--app-id；省略默认CS2，不能省略。
2. 每游戏独立stream_id/cursor、分析结果、窗口分母与角色配置。用(app_id,review_id)关联评论，实体任务再加entity_id；不能合并三游戏的词频或情感统计。正文提到另一游戏也不改变来源app_id。响应逐条验证app_id，错游戏、错流或未知版本停止，不推进失败批次。
3. 默认配置会同时采三游戏。API中的app_id仅选择读取对象，不需要修改爬虫。使用运行中同一份API即可；最终同机整合只启动一份采集服务，两种分析分别消费它。

二、接入验收
1. 新环境安装依赖并运行doctor。先--sample验证虚构样例，health为offline/disabled；停止后不带--sample启动真实采集，health为live。source=steam本身不能区分样例与真实。用不同消费者名称隔离demo和live。
2. 三游戏分别通过API读取评论并核对health、app_id、stream_id、字段、pipeline_versions和回填状态；不给不同游戏拼接输入。数据暂空时检查data_ready/last_error，勿伪造记录。
3. 先用examples/consume_api.py --consumer trend_live --app-id <ID> --once验证，重跑验证保存游标，去掉--once可持续轮询。API默认http://127.0.0.1:8000，端口改变时必须同时传--base-url，消费者不会自动读config.json。不要每次启动重置状态。
4. 正式输入用/v1/reviews/changes?app_id=<ID>&cursor=<cursor>&limit=100，从0重放。items是事件，items[].review是完整评论；当前reviews接口只便于抽查，过滤后的当前列表不能代替changes。支持已知clean-en-v1/v2/v3历史事件，追到当前水位后统一当前清洗版本，未知版本立即停止。
5. 对每条upsert按ID/revision幂等更新，先减旧贡献再加新贡献；usable标记true变false也撤销旧贡献。按UTC created_at归发布时间窗口，不能把回填/修改/重清洗当新发布。分析结果、记录与游标成功提交后才能推进；复用save_batch(...,app_id=...,on_upsert=...)或等价事务语义。
6. 示例消费者只保存数据与进度，并不执行分析。第一次接入算法使用新的trend_algorithm_v1消费者和空分析表，或全量重建历史。默认--reset不会替你重置新增分析表。
7. 首次目标回填30天，未完成分页会续跑，完成后约600秒目标间隔采集；Steam可能缓存，属于近实时。开发可先开始；backfill未完成、历史不足、样本不足或源数据陈旧时标注状态，不把缺失当零或发布完整窗口结论。质量标记是启发式，以本角色对应usable字段决定纳入，不按uncertain一刀切。

补充：程序1.3.0已提供votes_up（认为评测有用的人数）和comment_count（评测下回复数）。它们为非负整数或null，保留给后续结果消费者；未知不能当0，样例值虚构。互动数变化也产生revision/upsert，不是新评论；文本/可用性/清洗及算法配置不变时可复用旧分析结果。旧评测互动数主要随每日全范围校对刷新，不保证所有计数每10分钟更新。原有游标继续使用，旧历史事件没有计数时允许缺失/null。

三、本角色：趋势词检测
1. 直接读取tokens_trend、created_at、usable_for_trend，保留review_id/revision/pipeline_version。tokens已去停用词并统一部分词形/术语，保留重复次数；不要再爬取、重新清洗或把三款游戏混合分词。若额外加领域停用词或短语规则，分游戏配置并记录算法版本；短语从完整text_clean识别，不能从删词后邻接猜短语。
2. 实现词频随时间变化的趋势检测。默认建议每分钟评估一次UTC锚点T，对同一游戏比较互不重叠的[T-1h,T)与[T-25h,T-1h)。按相同长度的单位时间或评论/词项量归一，不能直接比较1小时与24小时总次数。保留原始频数、分母、归一率和趋势强度，明确定义词频TF或文档频率DF；若DF每评论同词只算一次。
3. 设可配置平滑、最小近期出现次数、最小评论量与阈值。基线零出现应标注新出现并采用有限强度或明确状态，避免无穷大。不要把开发默认公式宣称为标准答案或统计显著性，记录算法版本和全部参数。
4. 首版需要分游戏输出当前趋势列表、强度、近期/基线支持量、窗口、computed_at与数据/分析水位。建议输出字段app_id、term、window_start/end、baseline_start/end、recent_count、baseline_count、recent_denominator、baseline_denominator、strength、is_trending、algorithm_version、computed_at、source_stream_id、processed_cursor、data_status；字段名可清晰调整，但语义必须完整并提供说明。
5. 下游存储放analysis/games/<app_id>/等隔离目录，或使用始终带app_id的结果表。用相同词出现在两个游戏、评论修改、可用性变false、重复批次、迟到回填、空基线/稀疏窗口等案例验证。分析聚合用当前已知评论最新版本修正其原发布时间窗口，不能声称还原采集前编辑历史。
6. 给出可持续运行的分析入口和供下一位同学读取的分游戏结果契约。本次不制作图表。

四、完成时报告
给出实际执行命令、三游戏各自读取数量和回填状态、游戏隔离与失败回滚验证、重跑和重启游标证据、自己的算法启动命令、算法选择/参数/限制、分游戏结果路径。提供可复现的小样本验证和一条真实评论的输入输出。没有数据或算法未完成时如实报告，不把虚构样例或消费者镜像说成真实分析结果。

```
